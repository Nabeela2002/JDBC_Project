package hospitalmanagement;

import java.sql.*;
import java.util.Scanner;

public class Patient {
    private Connection connection;
    private Scanner scanner;

    public Patient(Connection connection, Scanner scanner){
        this.connection = connection;
        this.scanner = scanner;
    
}

    public void addPatient(){
        System.out.print("Enter Patient Name: ");
        String name = scanner.next();
        System.out.print("Enter Patient Age: ");
        int age = scanner.nextInt();
        System.out.print("Enter Patient Gender: ");
        String gender = scanner.next();
        
        
        
        try{
            String query = "INSERT INTO patients(name, age, gender) VALUES(?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setInt(2, age);
            preparedStatement.setString(3, gender);
            int affectedRows = preparedStatement.executeUpdate();
            if(affectedRows>0){
                System.out.println("Patient Added Successfully!!");
            }else{
                System.out.println("Failed to add Patient!!");
            }

        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public void viewPatients(){
        String query = "select * from patients";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            ResultSet resultSet = preparedStatement.executeQuery();
            System.out.println("Patients: ");
            System.out.println("+------------+--------------------+----------+------------+");
            System.out.println("| Patient Id | Name               | Age      | Gender     |");
            System.out.println("+------------+--------------------+----------+------------+");
            while(resultSet.next()){
                int id = resultSet.getInt("id");
                String name = resultSet.getString("name");
                int age = resultSet.getInt("age");
                String gender = resultSet.getString("gender");
                System.out.printf("| %-10s | %-18s | %-8s | %-10s |\n", id, name, age, gender);
                System.out.println("+------------+--------------------+----------+------------+");
            }

        }catch (SQLException e){
            e.printStackTrace();
        }
    }

    public boolean getPatientById(int id){
        String query = "SELECT * FROM patients WHERE id = ?";
        try{
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setInt(1, id);
            ResultSet resultSet = preparedStatement.executeQuery();
            if(resultSet.next()){
                return true;
            }else{
                return false;
            }
        }catch (SQLException e){
            e.printStackTrace();
        }
        return false;
    }
    public static void updatepatient(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter patient id to update: ");
            int pid = scanner.nextInt();
            scanner.nextLine(); // Consume the newline character

            if (!patientsExists(connection, pid)) {
                System.out.println("patient not found for the given ID.");
                return;
            }

            System.out.print("Enter patient name to be updated: ");
            String newpatientName = scanner.nextLine();
            System.out.print("Enter the age: ");
            int nage = scanner.nextInt();
            System.out.print("Enter the gender: ");
            String ngender = scanner.next();

            String sql = "UPDATE patients SET name = '" + newpatientName + "', " +
                    "age = " + nage + ", " +
                    "gender = '" + ngender + "' " +
                    "WHERE id = " + pid;

            try (Statement statement = connection.createStatement()) {
                int affectedRows = statement.executeUpdate(sql);

                if (affectedRows > 0) {
                    System.out.println("patient updated successfully!");
                } else {
                    System.out.println("patient update failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    public static void deletepatient(Connection connection, Scanner scanner) {
        try {
            System.out.print("Enter patient ID to delete: ");
            int pid = scanner.nextInt();

            if (!patientsExists(connection, pid)) {
                System.out.println("patient not found for the given ID.");
                return;
            }

            String sql = "DELETE FROM patients WHERE id = " + pid;

            try (Statement statement = connection.createStatement()) {
                int affectedRows = statement.executeUpdate(sql);

                if (affectedRows > 0) {
                    System.out.println("Reservation deleted successfully!");
                } else {
                    System.out.println("Reservation deletion failed.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }




private static boolean patientsExists(Connection connection, int pid) {
    try {
        String sql = "SELECT id FROM patients WHERE id = " + pid;

        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {

            return resultSet.next(); // If there's a result, the patient exists
        }
    } catch (SQLException e) {
        e.printStackTrace();
        return false; // Handle database errors as needed
    }


}
}


